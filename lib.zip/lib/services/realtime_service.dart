import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'package:mess_prototype/services/server_config.dart';

enum RealtimeConnectionState {
  disconnected,
  connecting,
  connected,
  reconnecting,
}

class RealtimeService extends ChangeNotifier {
  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  Timer? _reconnectTimer;

  String? _token;

  bool _shouldReconnect = false;
  bool _connecting = false;

  int _reconnectAttempts = 0;

  RealtimeConnectionState _state =
      RealtimeConnectionState.disconnected;

  final StreamController<Map<String, dynamic>> _events =
      StreamController<Map<String, dynamic>>.broadcast();

  RealtimeConnectionState get state => _state;

  bool get isConnected =>
      _state == RealtimeConnectionState.connected;

  Stream<Map<String, dynamic>> get events => _events.stream;

  Future<bool> connect(String token) async {
    if (token.isEmpty) {
      return false;
    }

    _token = token;
    _shouldReconnect = true;

    _reconnectTimer?.cancel();
    _reconnectTimer = null;

    if (_state == RealtimeConnectionState.connected) {
      return true;
    }

    if (_connecting) {
      return false;
    }

    return _connect();
  }

  Future<bool> _connect() async {
    if (_connecting) {
      return false;
    }

    final token = _token;

    if (!_shouldReconnect ||
        token == null ||
        token.isEmpty) {
      return false;
    }

    _connecting = true;

    final isReconnect = _reconnectAttempts > 0;

    _setState(
      isReconnect
          ? RealtimeConnectionState.reconnecting
          : RealtimeConnectionState.connecting,
    );

    try {
      await _disposeCurrentConnection();

      final channel = IOWebSocketChannel.connect(
        Uri.parse(ServerConfig.wsUrl),
        headers: {
          'Authorization': 'Bearer $token',
          'Origin': ServerConfig.apiBaseUrl,
        },
        pingInterval: const Duration(seconds: 20),
      );

      _channel = channel;

      await channel.ready;

      if (!_shouldReconnect || !identical(_channel, channel)) {
        await channel.sink.close();

        if (identical(_channel, channel)) {
          _channel = null;
        }

        _setState(RealtimeConnectionState.disconnected);

        return false;
      }

      _reconnectAttempts = 0;

      _subscription = channel.stream.listen(
        _handleMessage,
        onError: (Object error, StackTrace stackTrace) {
          _handleSocketError(channel, error);
        },
        onDone: () {
          _handleSocketDone(channel);
        },
        cancelOnError: false,
      );

      _setState(RealtimeConnectionState.connected);

      return true;
    } catch (error) {
      debugPrint('Realtime connection error: $error');

      if (_shouldReconnect) {
        _scheduleReconnect();
      }

      _setState(RealtimeConnectionState.disconnected);

      return false;
    } finally {
      _connecting = false;
    }
  }

  void _handleMessage(dynamic rawMessage) {
    try {
      final dynamic decoded;

      if (rawMessage is String) {
        decoded = jsonDecode(rawMessage);
      } else if (rawMessage is List<int>) {
        decoded = jsonDecode(utf8.decode(rawMessage));
      } else {
        return;
      }

      if (decoded is! Map<String, dynamic>) {
        return;
      }

      _events.add(decoded);
    } catch (error) {
      debugPrint('Realtime invalid message: $error');
    }
  }

  bool send({
    required String type,
    Map<String, dynamic>? data,
  }) {
    final channel = _channel;

    if (!isConnected || channel == null) {
      return false;
    }

    try {
      channel.sink.add(
        jsonEncode({
          'type': type,
          'data': data ?? <String, dynamic>{},
        }),
      );

      return true;
    } catch (error) {
      debugPrint('Realtime send error: $error');
      return false;
    }
  }

  Future<void> disconnect() async {
    _shouldReconnect = false;
    _token = null;
    _reconnectAttempts = 0;

    _reconnectTimer?.cancel();
    _reconnectTimer = null;

    await _disposeCurrentConnection();

    _setState(RealtimeConnectionState.disconnected);
  }

  void _handleSocketError(
    WebSocketChannel channel,
    Object error,
  ) {
    debugPrint('Realtime socket error: $error');

    if (!identical(_channel, channel)) {
      return;
    }

    _subscription = null;
    _channel = null;

    _setState(RealtimeConnectionState.disconnected);

    if (_shouldReconnect) {
      _scheduleReconnect();
    }
  }

  void _handleSocketDone(WebSocketChannel channel) {
    if (!identical(_channel, channel)) {
      return;
    }

    _subscription = null;
    _channel = null;

    _setState(RealtimeConnectionState.disconnected);

    if (_shouldReconnect) {
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    if (!_shouldReconnect ||
        _reconnectTimer != null ||
        _connecting) {
      return;
    }

    _reconnectAttempts++;

    final delaySeconds =
        _reconnectAttempts.clamp(1, 10);

    _reconnectTimer = Timer(
      Duration(seconds: delaySeconds),
      () {
        _reconnectTimer = null;

        if (!_shouldReconnect) {
          return;
        }

        unawaited(_connect());
      },
    );
  }

  Future<void> _disposeCurrentConnection() async {
    final subscription = _subscription;
    _subscription = null;

    if (subscription != null) {
      try {
        await subscription.cancel();
      } catch (_) {}
    }

    final channel = _channel;
    _channel = null;

    if (channel != null) {
      try {
        await channel.sink.close();
      } catch (_) {}
    }
  }

  void _setState(RealtimeConnectionState value) {
    if (_state == value) {
      return;
    }

    _state = value;
    notifyListeners();
  }

  @override
  void dispose() {
    _shouldReconnect = false;

    _reconnectTimer?.cancel();
    _reconnectTimer = null;

    _subscription?.cancel();
    _subscription = null;

    _channel?.sink.close();
    _channel = null;

    _events.close();

    super.dispose();
  }
}